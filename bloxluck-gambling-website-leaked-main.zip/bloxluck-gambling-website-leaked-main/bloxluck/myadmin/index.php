<?php

include_once('adminer.php');

?>